var config = {
    map: {
        '*': {
            "quickSearch" : "TemplateMonster_AjaxSearch/js/tm-search-ajax"
        }
    },
};