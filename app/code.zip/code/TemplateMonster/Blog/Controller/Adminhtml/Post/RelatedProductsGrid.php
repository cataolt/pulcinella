<?php

namespace TemplateMonster\Blog\Controller\Adminhtml\Post;

class RelatedProductsGrid extends RelatedProducts
{
}
