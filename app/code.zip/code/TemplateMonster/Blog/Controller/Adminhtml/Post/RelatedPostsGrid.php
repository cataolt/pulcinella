<?php

namespace TemplateMonster\Blog\Controller\Adminhtml\Post;

class RelatedPostsGrid extends RelatedPosts
{
}
