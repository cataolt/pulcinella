define(['Manadev_Core/js/UrlParser'], function(UrlParser) {
    return new UrlParser();
});