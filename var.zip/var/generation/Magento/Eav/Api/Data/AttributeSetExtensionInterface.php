<?php
namespace Magento\Eav\Api\Data;

/**
 * ExtensionInterface class for @see \Magento\Eav\Api\Data\AttributeSetInterface
 */
interface AttributeSetExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
